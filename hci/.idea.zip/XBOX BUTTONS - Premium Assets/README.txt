---THANK YOU---
Thank you for showing interest in this project.
- Made by Arks @scissormarks


---SPECIFICATION---
- This assetspack contains 228 different input elements.
- Each input has a respective SVG (vector file) and PNG. (image file at 480px*480px)
- The files contained in this pack has been sorted into groups based on input type.
- Some inputs have different variations - these can be used based on preference or for state changes like when holding down an input.
- The font used for the project is Open Sans - Semibold which is a free to use font type. (https://fonts.google.com/specimen/Open+Sans=


---CONTENT OF ASSETPACK--- (462 files)
- 6 ROOT
- 96 Analog Inputs
- 22 Analog Triggers
- 28 Directional Arrows
- 96 Digital Buttons
- 228 Svg fils

---ACCREDITATION---
The accredidation for the work should be label as "UI Elements" (or something to a similar effect) crediting "Mikkel Julian 'Arks' Petersen" or "Arks @Scissormarks" and if relevant; should including these social media links:
- @ScissorMarks (on twitter)
- https://arks.itch.io
- https://arks.itch.io/xbox-buttons


---SOCIAL LINKS---
https://arks.itch.io/
https://twitter.com/ScissorMarks
https://arksiscool.uwu.ai/


---LEGAL---
*Xbox® and the Xbox® logo are registered trademarks of Microsoft.